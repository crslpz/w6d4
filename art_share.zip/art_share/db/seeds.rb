# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

artworks = Artwork.create([
    {title: "chocolate sauce", artist_id: 2, image_url: "chocolateLove.com"},
    {title: "banana split", artist_id: 1, image_url: "bananas.com"},
    {title: "boat on the sea", artist_id: 1, image_url: "boatsRfun.com"},
    {title: "cars burning rubber", artist_id: 1, image_url: "autos.com"}])

users = User.create([
    {username: 'Drake Collins'}, 
    {username: 'Sergio'},
    {username: 'Phil Collins'},
    {username: 'Shakira'}])

artwork_shares = ArtworkShare.create([
    {artwork_id: 4, viewer_id: 4 }, 
    {artwork_id: 3, viewer_id: 3}])
    